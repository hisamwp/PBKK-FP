<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cart_model extends MY_Model 
{

	public $table = 'cart';

}

/* End of file Cart_model.php */
